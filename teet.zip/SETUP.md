# FLUKS në Cloudflare (Workers + R2)

Videot ruhen në **Cloudflare R2** dhe shkojnë drejtpërdrejt aty, jo nëpërmjet funksioneve Netlify. Kështu nuk ka më kuota të vogla funksionesh, dhe shikimi/shkarkimi i videove nuk ka pagesë trafiku.

## Çfarë të duhet (një herë)
1. Llogari **Cloudflare** (falas): https://dash.cloudflare.com/sign-up
2. **R2** kërkon një kartë bankare në llogari, edhe për pjesën falas. Te dashboard: **Storage & databases → R2 object storage** → aktivizo planin.
   - Falas: 10 GB ruajtje. Pastaj ~$0.015 për GB në muaj. Një video 56 GB është rreth $0.85 në muaj, dhe skadimi automatik e fshin.
3. Krijo bucket-in: **R2 → Create bucket** → emri `fluks-videos` (saktësisht ky, ose ndrysho `bucket_name` te `wrangler.toml`).
4. Instalo **Node.js** (versioni LTS): https://nodejs.org

## Publikimi
Hap folderin e zhpaketuar në Terminal/PowerShell (në Windows: kliko me të djathtën në folder → "Open in Terminal") dhe ekzekuto:

```
npm install
npx wrangler login
npx wrangler deploy
```

`wrangler login` hap shfletuesin që të lejosh hyrjen. Në fund shfaqet adresa, p.sh. `https://fluks.EMRI-YT.workers.dev`.

Hap `https://fluks.EMRI-YT.workers.dev/api/health`. Duhet të shfaqet `{"ok":true,...}`. Pastaj provo një video të vogël.

Për ndryshime të mëtejshme, ekzekuto vetëm `npx wrangler deploy`.

## Fjalëkalimet dhe sekretet
Kodi nuk ka më fjalëkalim admini brenda tij. Vendose ti:

```
npx wrangler secret put ADMIN_PASSWORD
npx wrangler secret put IP_HASH_SALT
```

Të dyja të pyesin për vlerën (shkruaj një tekst të gjatë të rastësishëm për `IP_HASH_SALT`). Pa `ADMIN_PASSWORD`, paneli `/admin` është i fikur.

## Cilësime të tjera
Ndryshohen te `[vars]` në `wrangler.toml` (pastaj `npx wrangler deploy`):

| Emri | Qëllimi |
|---|---|
| `CONTACT_EMAIL` | Email-i që shfaqet te Kontakt, Kushtet dhe Privatësia |
| `PUBLIC_URL` | Adresa publike për linqet (p.sh. domeni yt) |
| `MAX_FILE_GB` | Madhësia maksimale e një videoje (paracaktuar 200) |
| `DAILY_GB_PER_IP` | Kufiri ditor i ngarkimit për IP në GB (pa limit nëse mungon) |
| `UPLOADS_PER_HOUR` | Ngarkime për orë për IP (pa limit nëse mungon) |
| `MAX_TOTAL_GB` | Kufiri total i ruajtjes; ngarkimet e reja ndalen kur arrihet |
| `TURNSTILE_SITE_KEY` | Çelësi publik i Turnstile (opsional) |

Sekret (me `wrangler secret put`): `TURNSTILE_SECRET`. Vendos të dyja Turnstile ose asnjërën.

## Domeni yt
Te Cloudflare: **Workers & Pages → fluks → Settings → Domains & Routes → Add → Custom domain**.

## Si funksionon ngarkimi
- Videoja ndahet në pjesë 16 MB (më të mëdha për skedarë shumë të mëdhenj) dhe ngarkohet 4 pjesë njëherësh.
- Çdo pjesë provohet sërish automatikisht nëse dështon. Nëse ndërpritet krejt, zgjidh të njëjtin skedar dhe vazhdon aty ku mbeti (sesioni mbahet 72 orë).
- Faqja duhet të mbetet e hapur gjatë ngarkimit. Përdor Chrome ose Edge.
- Shkarkimi i videove mbi 1.5 GB punon vetëm në Chrome/Edge në kompjuter.
- Fshirja e videove të skaduara bëhet automatikisht çdo orë.
- Videot e vjetra që ishin te Netlify nuk transferohen (ato skadojnë vetë).
