(function () {
  var K = "fluks:theme", t = null;
  try { t = localStorage.getItem(K); } catch (e) {}
  if (!t && window.matchMedia && matchMedia("(prefers-color-scheme: light)").matches) t = "light";
  function apply(v) { document.documentElement.setAttribute("data-theme", v); var m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute("content", v === "light" ? "#f6f4ef" : "#0b0b0d"); }
  apply(t === "light" ? "light" : "dark");
  document.addEventListener("DOMContentLoaded", function () {
    var nav = document.querySelector("nav.main"); if (!nav) return;
    var b = document.createElement("button"); b.type = "button"; b.className = "themebtn"; b.setAttribute("aria-label", "Ndrysho temën");
    function icon() { b.textContent = document.documentElement.getAttribute("data-theme") === "light" ? "☾" : "☀"; }
    icon();
    b.onclick = function () {
      var n = document.documentElement.getAttribute("data-theme") === "light" ? "dark" : "light";
      apply(n); icon(); try { localStorage.setItem(K, n); } catch (e) {}
    };
    nav.insertBefore(b, nav.firstChild);
  });
})();
