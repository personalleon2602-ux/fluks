(function () {
  var card = document.getElementById("card");
  if (!card) return;
  var $ = function (id) { return document.getElementById(id); };
  var views = ["v-idle", "v-busy", "v-done", "v-err"];
  function show(id) { views.forEach(function (v) { $(v).classList.toggle("hidden", v !== id); }); }
  var input = $("file"), ctrl = null, cancelled = false;

  function fmt(b) {
    var u = ["B", "KB", "MB", "GB", "TB"], i = 0;
    while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
    return b.toFixed(i > 1 ? 1 : 0) + " " + u[i];
  }
  function fail(msg) { $("err-msg").textContent = msg; show("v-err"); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function api(path, body, signal) {
    return fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: signal })
      .then(function (r) { return r.json().catch(function () { return null; }).then(function (d) { return { ok: r.ok, status: r.status, data: d }; }); });
  }
  function duration(file) {
    return new Promise(function (resolve) {
      var url = URL.createObjectURL(file), v = document.createElement("video");
      var t = setTimeout(function () { done(0); }, 4000);
      function done(n) { clearTimeout(t); URL.revokeObjectURL(url); resolve(n); }
      v.preload = "metadata";
      v.onloadedmetadata = function () { done(v.duration || 0); };
      v.onerror = function () { done(0); };
      v.src = url;
    });
  }
  function putChunk(url, blob, signal, onBytes) {
    return new Promise(function (resolve, reject) {
      var x = new XMLHttpRequest();
      x.open("PUT", url); x.timeout = 0;
      x.upload.onprogress = function (e) { onBytes(e.loaded); };
      x.onload = function () { var d = null; try { d = JSON.parse(x.responseText); } catch (e) {} resolve({ status: x.status, data: d }); };
      x.onerror = function () { resolve({ status: 0, data: null }); };
      x.onabort = function () { reject(new DOMException("Aborted", "AbortError")); };
      if (signal.aborted) return reject(new DOMException("Aborted", "AbortError"));
      var onAbort = function () { x.abort(); };
      signal.addEventListener("abort", onAbort, { once: true });
      var clean = function () { signal.removeEventListener("abort", onAbort); };
      x.addEventListener("loadend", clean);
      x.send(blob);
    });
  }
  function human(sec) {
    sec = Math.max(0, Math.round(sec));
    var d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), x = sec % 60;
    if (d) return d + " ditë " + h + " orë";
    if (h) return h + " orë " + m + " min";
    if (m) return m + " min " + x + " s";
    return x + " s";
  }
  var t0 = 0, base = 0, expTimer = null, qLabel = "";
  var HKEY = "fluks:history";
  var pubBase = location.origin;
  function siteBase() { return pubBase; }
  var tsId = null, tsKey = "", tsRes = null, tsRej = null;
  var ready = fetch("/api/health").then(function (r) { return r.json(); }).then(function (h) {
    if (h.publicUrl && /^https?:\/\//.test(h.publicUrl)) pubBase = h.publicUrl;
    if (!h.turnstileSiteKey) return;
    tsKey = h.turnstileSiteKey;
    return new Promise(function (resolve) {
      var sc = document.createElement("script");
      sc.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"; sc.async = true;
      sc.onload = function () {
        tsId = window.turnstile.render("#ts", {
          sitekey: tsKey, execution: "execute", appearance: "interaction-only",
          callback: function (t) { if (tsRes) tsRes(t); },
          "error-callback": function () { if (tsRej) tsRej(new Error("Verifikimi dështoi.")); }
        });
        resolve();
      };
      sc.onerror = resolve;
      document.head.appendChild(sc);
    });
  }).catch(function () {});
  function getToken() {
    return ready.then(function () {
      if (!tsKey || tsId === null) return "";
      return new Promise(function (res, rej) {
        tsRes = res; tsRej = rej;
        try { window.turnstile.reset(tsId); window.turnstile.execute(tsId); } catch (e) { rej(e); }
      });
    });
  }
  function eta(sum) {
    var el = (Date.now() - t0) / 1000, got = sum - base;
    if (el < 3 || got <= 0) return;
    var speed = got / el;
    $("eta").textContent = fmt(speed) + "/s · kaluan " + human(el) + " · mbeten rreth " + human((file0.size - sum) / speed);
  }
  var file0 = null;
  function confetti(host) {
    if (window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    var cols = ["#ff4b33", "#ff7a5c", "#f4f1ea", "#ffc247", "#8f8f96"];
    for (var i = 0; i < 46; i++) {
      var c = document.createElement("span"); c.className = "cf";
      var a = Math.random() * Math.PI * 2, d = 90 + Math.random() * 170;
      c.style.setProperty("--x", Math.cos(a) * d + "px");
      c.style.setProperty("--y", Math.sin(a) * d * 0.8 + 60 + "px");
      c.style.setProperty("--r", (Math.random() * 720 - 360) + "deg");
      c.style.background = cols[i % cols.length];
      host.appendChild(c);
      setTimeout(function (el) { el.remove(); }, 1700, c);
    }
  }
  function showQr(link) {
    var box = $("qr"); box.hidden = true; box.textContent = "";
    function build() {
      try {
        var q = window.qrcode(0, "M"); q.addData(link); q.make();
        box.innerHTML = q.createSvgTag(5, 2); box.hidden = false;
        var sv = box.querySelector("svg"); if (sv) { sv.setAttribute("width", "148"); sv.setAttribute("height", "148"); }
        var cap = document.createElement("small"); cap.textContent = "Skano me telefon"; box.appendChild(cap);
      } catch (e) {}
    }
    if (window.qrcode) return build();
    var sc = document.createElement("script");
    sc.src = "https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js";
    sc.onload = build; document.head.appendChild(sc);
  }
  function setPct(f) {
    var p = Math.max(0, Math.min(100, Math.floor(f * 100)));
    $("pct").firstChild.nodeValue = p; $("bar").style.width = p + "%"; $("fly").style.setProperty("--f", p / 100);
  }

  function history() { try { return JSON.parse(localStorage.getItem(HKEY) || "[]"); } catch (e) { return []; } }
  function remember(item) {
    var h = history().filter(function (x) { return x.exp > Date.now(); });
    h.unshift(item);
    try { localStorage.setItem(HKEY, JSON.stringify(h.slice(0, 100))); } catch (e) {}
    renderMine();
  }
  function removeFromHistory(url) {
    var h = history().filter(function (x) { return x.url !== url; });
    try { localStorage.setItem(HKEY, JSON.stringify(h)); } catch (e) {}
    renderMine();
  }
  function renderMine() {
    var h = history().filter(function (x) { return x.exp > Date.now(); }), box = $("mine"), list = $("mine-list");
    if (!box || !list) return;
    list.textContent = "";
    box.classList.toggle("hidden", !h.length);
    h.forEach(function (x) {
      var row = document.createElement("div");
      row.style.cssText = "border:1px solid var(--line);border-radius:1rem;padding:.9rem 1rem;background:var(--coal2);display:flex;gap:.75rem;align-items:center;justify-content:space-between;flex-wrap:wrap";
      var info = document.createElement("div"); info.style.minWidth = "0";
      var nm = document.createElement("b"); nm.textContent = x.name; nm.style.cssText = "display:block;word-break:break-word";
      var meta = document.createElement("span"); meta.className = "small";
      var cn = {}; try { cn = (JSON.parse(localStorage.getItem("fluks:counts") || "{}"))[x.url.split("/")[2]] || {}; } catch (e) {}
      meta.textContent = fmt(x.size) + " · skadon pas " + human((x.exp - Date.now()) / 1000) + (cn.v || cn.d ? " · " + (cn.v || 0) + " hapje · " + (cn.d || 0) + " shkarkime" : "");
      info.appendChild(nm); info.appendChild(meta);
      var acts = document.createElement("div"); acts.style.cssText = "display:flex;gap:.5rem;flex-wrap:wrap";
      var cp = document.createElement("button"); cp.className = "btn ghost"; cp.type = "button"; cp.textContent = "Kopjo";
      cp.onclick = function () { navigator.clipboard.writeText(siteBase() + x.url).then(function () { cp.textContent = "✓"; setTimeout(function () { cp.textContent = "Kopjo"; }, 1500); }); };
      var op = document.createElement("a"); op.className = "btn ghost"; op.textContent = "Hape"; op.href = siteBase() + x.url; op.target = "_blank"; op.rel = "noopener";
      var dl = document.createElement("button"); dl.className = "btn ghost"; dl.type = "button"; dl.textContent = "Fshi";
      dl.onclick = function () {
        dl.disabled = true; dl.textContent = "Po fshihet…";
        var slug = x.url.split("/")[2], token = (x.del.split("#token=")[1] || "");
        fetch("/api/video/" + encodeURIComponent(slug) + "/delete", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: token }) })
          .then(function (r) {
            // 404 = videoja nuk ekziston më (e fshirë ose e skaduar): rreshti hiqet gjithsesi
            if (r.ok || r.status === 404) { removeFromHistory(x.url); return; }
            return r.json().catch(function () { return null; }).then(function (d) {
              dl.disabled = false; dl.textContent = "Fshi";
              alert((d && d.error) || "Fshirja dështoi. Provo sërish.");
            });
          })
          .catch(function () { dl.disabled = false; dl.textContent = "Fshi"; alert("Fshirja dështoi. Kontrollo lidhjen dhe provo sërish."); });
      };
      acts.appendChild(cp); acts.appendChild(op); acts.appendChild(dl);
      row.appendChild(info); row.appendChild(acts); list.appendChild(row);
    });
  }
  renderMine();
  window.addEventListener("fluks:counts", renderMine);

  async function upload(file) {
    ctrl = new AbortController(); cancelled = false; file0 = file; t0 = Date.now(); base = 0; $("eta").textContent = "";
    var signal = ctrl.signal;
    $("fname").textContent = qLabel + file.name + " · " + fmt(file.size);
    setPct(0); show("v-busy");
    try {
      var sig = "fluks:" + file.name + ":" + file.size + ":" + file.lastModified;
      var id = null, size = 0, total = 0, loaded = {}, done = {};
      try {
        var saved = localStorage.getItem(sig);
        if (saved) {
          var st = await fetch("/api/upload/status?id=" + encodeURIComponent(saved), { signal: signal });
          if (st.ok) {
            var sd = await st.json();
            id = sd.id; size = sd.chunkSize; total = sd.total;
            sd.have.forEach(function (n) { done[n] = true; loaded[n] = Math.min(size, file.size - n * size); });
          } else if (st.status === 404 || st.status === 400) localStorage.removeItem(sig);
          else return fail("Serveri nuk u përgjigj (kodi " + st.status + "). Provo sërish pas pak — ngarkimi do të vazhdojë aty ku mbeti.");
        }
      } catch (e) { if (signal.aborted) throw e; return fail("Lidhja dështoi gjatë kontrollit të ngarkimit. Provo sërish — do të vazhdojë aty ku mbeti."); }
      if (!id) {
        var init = await api("/api/upload/init", { fileName: file.name, mimeType: file.type, size: file.size, duration: await duration(file), ttlHours: Number($("ttl").value), password: $("vpw").value, cfToken: await getToken() }, signal);
        if (!init.ok || !init.data) return fail((init.data && init.data.error) || "Ngarkimi nuk mund të nisë.");
        id = init.data.id; size = init.data.chunkSize; total = init.data.total;
        try { localStorage.setItem(sig, id); } catch (e) {}
      }
      var nextPart = 0, failure = null, wake = null;
      for (var k0 in loaded) base += loaded[k0];
      t0 = Date.now();
      try { if (navigator.wakeLock) wake = await navigator.wakeLock.request("screen"); } catch (e) {}

      function progress() {
        var sum = 0; for (var k in loaded) sum += loaded[k];
        setPct(sum / file.size); eta(sum);
      }
      async function sendPart(n) {
        var start = n * size, blob = file.slice(start, Math.min(start + size, file.size));
        for (var attempt = 0; ; attempt++) {
          if (signal.aborted) throw new DOMException("Aborted", "AbortError");
          while (navigator.onLine === false) await sleep(1500);
          var r = await putChunk("/api/upload/chunk?id=" + id + "&index=" + n, blob, signal, function (b) { loaded[n] = b; progress(); });
          if (r.status === 200) { loaded[n] = blob.size; done[n] = true; progress(); return; }
          if (r.status === 404 || r.status === 400) throw new Error((r.data && r.data.error) || "Ngarkimi u ndërpre.");
          loaded[n] = 0; progress();
          // gabime kalimtare (rrjet, 5xx, 429): provo sërish me pritje gjithnjë më të gjatë (deri ~15 min)
          if (attempt >= 40) throw new Error("Serveri ose lidhja nuk përgjigjet (kodi " + r.status + (r.data && r.data.detail ? ": " + r.data.detail : "") + ").");
          await sleep(Math.min(30000, 1000 * Math.pow(1.5, attempt)) + Math.random() * 500);
        }
      }
      async function worker() {
        while (!failure) {
          var n = nextPart++;
          if (n >= total) return;
          if (done[n]) continue;
          try { await sendPart(n); }
          catch (e) { if (!failure) failure = e; ctrl.abort(); }
        }
      }
      async function runParts() {
        nextPart = 0;
        await Promise.all([worker(), worker(), worker(), worker()]);
      }
      await runParts();
      if (failure) {
        if (wake) { try { wake.release(); } catch (e) {} }
        if (cancelled) { show("v-idle"); return; }
        return fail((failure.name === "AbortError" ? "Ngarkimi u ndërpre." : failure.message) + " Zgjidh të njëjtin skedar sërish dhe do të vazhdojë aty ku mbeti.");
      }

      var c = null;
      for (var ct = 0; ct < 8; ct++) {
        try { c = await api("/api/upload/complete", { id: id }, signal); }
        catch (e) { if (signal.aborted) throw e; c = { ok: false, status: 0, data: null }; }
        if (c.ok && c.data) break;
        if (c.status === 409) { // mungojnë pjesë: sinkronizo me serverin dhe dërgo vetëm ato që mungojnë
          try {
            var st2 = await fetch("/api/upload/status?id=" + encodeURIComponent(id), { signal: signal });
            if (st2.ok) { var sd2 = await st2.json(); done = {}; sd2.have.forEach(function (n) { done[n] = true; }); await runParts(); if (failure) break; continue; }
          } catch (e) { if (signal.aborted) throw e; }
        } else if (c.status && c.status < 500 && c.status !== 429) break;
        await sleep(Math.min(20000, 2000 * (ct + 1)));
      }
      if (wake) { try { wake.release(); } catch (e) {} }
      if (failure) return fail(failure.message + " Zgjidh të njëjtin skedar sërish dhe do të vazhdojë aty ku mbeti.");
      if (!c || !c.ok || !c.data) return fail(((c && c.data && c.data.error) || "Ngarkimi nuk u përfundua.") + (c && c.status ? " (kodi " + c.status + ")" : "") + " Zgjidh të njëjtin skedar sërish për ta përfunduar.");
      try { localStorage.removeItem(sig); } catch (e) {}
      var link = siteBase() + c.data.url;
      $("link").textContent = link;
      var exp = new Date(c.data.expiresAt).getTime();
      function tick() {
        var left = (exp - Date.now()) / 1000;
        $("expinfo").textContent = left > 0 ? "Skadon më " + new Date(exp).toLocaleString("sq-AL", { dateStyle: "medium", timeStyle: "short" }) + " (pas " + human(left) + ")." : "Linku ka skaduar.";
      }
      tick(); clearInterval(expTimer); expTimer = setInterval(tick, 30000);
      $("took").textContent = "Linku u gjenerua për " + human((Date.now() - t0) / 1000) + ".";
      $("open").href = link;
      var msg = encodeURIComponent("Shiko videon: " + link), lk = encodeURIComponent(link);
      var pwUsed = $("vpw").value.trim();
      $("took").textContent += pwUsed ? " Fjalëkalimi i videos: " + pwUsed + " (jepja personit veçmas)." : "";
      showQr(link);
      $("sh-wa").href = "https://wa.me/?text=" + msg;
      $("sh-vb").href = "viber://forward?text=" + msg;
      $("sh-ms").href = "https://www.facebook.com/dialog/send?link=" + lk + "&app_id=291494419107518&redirect_uri=" + lk;
      $("sh-tg").href = "https://t.me/share/url?url=" + lk + "&text=" + encodeURIComponent("Shiko videon");
      if (navigator.share) { $("sh-nat").hidden = false; $("sh-nat").onclick = function () { navigator.share({ title: file.name, url: link }).catch(function () {}); }; }
      $("del").href = c.data.url + "/manage#token=" + c.data.deleteToken;
      remember({ name: file.name, size: file.size, url: c.data.url, del: c.data.url + "/manage#token=" + c.data.deleteToken, exp: exp });
      show("v-done");
      confetti($("v-done"));
      window.dispatchEvent(new Event("fluks:uploaded"));
      return true;
    } catch (e) {
      if (cancelled) show("v-idle"); else fail("Ndodhi një gabim. Provo sërish.");
    }
  }
  var VIDEO_RE = /\.(mp4|mov|webm|mkv|avi|m4v|mpg|mpeg|3gp|wmv|flv)$/i;
  var running = false;
  async function pick(files) {
    files = Array.prototype.slice.call(files || []);
    if (!files.length || running) return;
    var ok = files.filter(function (f) { return /^video\//.test(f.type) || VIDEO_RE.test(f.name); });
    if (!ok.length) return fail("Pranohen vetëm skedarë video (MP4, MOV, WEBM…).");
    running = true;
    try {
      for (var i = 0; i < ok.length; i++) {
        qLabel = ok.length > 1 ? "(" + (i + 1) + "/" + ok.length + ") " : "";
        if (!(await upload(ok[i]))) break;
      }
    } finally { qLabel = ""; running = false; }
  }
  input.addEventListener("change", function () { pick(input.files); input.value = ""; });
  ["dragenter", "dragover"].forEach(function (t) { card.addEventListener(t, function (e) { e.preventDefault(); card.classList.add("over"); }); });
  ["dragleave", "drop"].forEach(function (t) { card.addEventListener(t, function (e) { e.preventDefault(); card.classList.remove("over"); }); });
  card.addEventListener("drop", function (e) { pick(e.dataTransfer.files); });
  $("cancel").onclick = function () { cancelled = true; if (ctrl) ctrl.abort(); };
  $("retry").onclick = function () { show("v-idle"); };
  $("again").onclick = function () { show("v-idle"); };
  window.addEventListener("beforeunload", function (e) {
    if (!$("v-busy").classList.contains("hidden")) { e.preventDefault(); e.returnValue = ""; }
  });
  $("copy").onclick = function () {
    navigator.clipboard.writeText($("link").textContent).then(function () {
      $("copy").textContent = "U kopjua ✓"; setTimeout(function () { $("copy").textContent = "Kopjo linkun"; }, 2000);
    });
  };
})();
