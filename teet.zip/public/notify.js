(function () {
  var nav = document.querySelector("nav.main");
  if (!nav) return;
  var HK = "fluks:history", EK = "fluks:events", RK = "fluks:read", LK = "fluks:last", CK = "fluks:counts";
  function jget(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
  function jset(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  var baseTitle = document.title, events = jget(EK, []), readTs = jget(RK, 0), open = false, firstLoad = true;
  var regions = null; try { regions = new Intl.DisplayNames(["sq"], { type: "region" }); } catch (e) {}

  var wrap = document.createElement("div"); wrap.className = "bellwrap";
  wrap.innerHTML = '<button class="bell" type="button" aria-label="Njoftimet" aria-expanded="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg><b class="badge" hidden>0</b></button><div class="bellpanel" hidden><div class="bp-head"><b>Njoftimet</b><button type="button" class="bp-read">Shëno si të lexuara</button></div><div class="bp-list"></div><div class="bp-foot"></div></div>';
  nav.insertBefore(wrap, nav.firstChild);
  var btn = wrap.querySelector(".bell"), badge = wrap.querySelector(".badge"), panel = wrap.querySelector(".bellpanel"),
      list = wrap.querySelector(".bp-list"), foot = wrap.querySelector(".bp-foot");

  function names() { var m = {}; jget(HK, []).forEach(function (x) { m[x.url.split("/")[2]] = x.name; }); return m; }
  function ago(t) {
    var s = Math.max(0, (Date.now() - t) / 1000);
    if (s < 60) return "tani";
    if (s < 3600) return "para " + Math.floor(s / 60) + " min";
    if (s < 86400) return "para " + Math.floor(s / 3600) + " orësh";
    return "para " + Math.floor(s / 86400) + " ditësh";
  }
  function unread() { return events.filter(function (e) { return e.at > readTs; }).length; }
  function renderBadge() {
    var n = unread();
    badge.hidden = !n; badge.textContent = n > 99 ? "99+" : String(n);
    document.title = n ? "(" + n + ") " + baseTitle : baseTitle;
  }
  function render() {
    var nm = names();
    list.textContent = "";
    if (!events.length) { var em = document.createElement("p"); em.className = "bp-empty"; em.textContent = "Asnjë njoftim ende. Kur dikush hap ose shkarkon videon tënde, do ta shohësh këtu."; list.appendChild(em); }
    events.slice(0, 50).forEach(function (e) {
      var row = document.createElement("a"); row.className = "bp-item" + (e.at > readTs ? " new" : ""); row.href = "/v/" + e.slug; row.target = "_blank"; row.rel = "noopener";
      var ic = document.createElement("span"); ic.className = "bp-ic " + e.type; ic.textContent = e.type === "download" ? "↓" : "▶";
      var tx = document.createElement("span"); tx.className = "bp-tx";
      var t1 = document.createElement("b"); t1.textContent = (e.type === "download" ? "Dikush e shkarkoi" : "Dikush e hapi") + (nm[e.slug] ? " “" + nm[e.slug] + "”" : " videon");
      var cc = e.cc && e.cc !== "XX" && regions ? " · " + (regions.of(e.cc) || e.cc) : "";
      var t2 = document.createElement("small"); t2.textContent = ago(e.at) + cc;
      tx.appendChild(t1); tx.appendChild(t2); row.appendChild(ic); row.appendChild(tx); list.appendChild(row);
    });
    foot.textContent = "";
    if ("Notification" in window && Notification.permission === "default") {
      var b = document.createElement("button"); b.type = "button"; b.className = "bp-perm"; b.textContent = "Aktivizo njoftimet në pajisje";
      b.onclick = function () { Notification.requestPermission().then(render); };
      foot.appendChild(b);
    }
    var sm = document.createElement("small"); sm.textContent = "Njoftimet vijnë sa kohë faqja është e hapur (edhe në sfond).";
    foot.appendChild(sm);
  }
  function markRead() { var m = events.length ? Math.max.apply(null, events.map(function (e) { return e.at; })) : 0; readTs = Math.max(readTs, m, Date.now() - 1); jset(RK, readTs); renderBadge(); }
  function toggle(v) {
    open = v; panel.hidden = !v; btn.setAttribute("aria-expanded", v ? "true" : "false");
    if (v) render(); else { markRead(); render(); }
  }
  btn.onclick = function (e) { e.stopPropagation(); toggle(!open); };
  panel.onclick = function (e) { e.stopPropagation(); };
  wrap.querySelector(".bp-read").onclick = function () { markRead(); render(); };
  document.addEventListener("click", function () { if (open) toggle(false); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && open) toggle(false); });

  function poll() {
    var items = jget(HK, []).filter(function (x) { return x.exp > Date.now() && x.del; }).map(function (x) { return { slug: x.url.split("/")[2], token: (x.del.split("#token=")[1] || "") }; });
    if (!items.length) { renderBadge(); return; }
    fetch("/api/notifs", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items: items, since: jget(LK, 0) }) })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (!d) return;
        jset(CK, d.counts || {}); window.dispatchEvent(new Event("fluks:counts"));
        var have = {}; events.forEach(function (e) { have[e.id] = 1; });
        var fresh = (d.events || []).filter(function (e) { return !have[e.id]; });
        if (fresh.length) {
          events = fresh.concat(events).sort(function (a, b) { return b.at - a.at; }).slice(0, 200);
          jset(EK, events); jset(LK, Math.max(jget(LK, 0), events[0].at));
          if (!firstLoad) {
            btn.classList.remove("ring"); void btn.offsetWidth; btn.classList.add("ring");
            if ("Notification" in window && Notification.permission === "granted") {
              var nm = names(), e0 = fresh[0];
              try { new Notification("FLUKS", { body: (e0.type === "download" ? "Dikush e shkarkoi " : "Dikush e hapi ") + (nm[e0.slug] ? "“" + nm[e0.slug] + "”" : "videon tënde") + (fresh.length > 1 ? " (+" + (fresh.length - 1) + " të tjera)" : ""), icon: "/icon.svg" }); } catch (x) {}
            }
          }
          if (open) render();
        }
        firstLoad = false; renderBadge();
      }).catch(function () {});
  }
  renderBadge(); render(); poll();
  setInterval(function () { if (!document.hidden) poll(); }, 20000);
  document.addEventListener("visibilitychange", function () { if (!document.hidden) poll(); });
  window.addEventListener("fluks:uploaded", poll);
})();
