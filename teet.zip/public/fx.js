(function(){
"use strict";
var reduce=window.matchMedia&&matchMedia("(prefers-reduced-motion:reduce)").matches;
var fine=window.matchMedia&&matchMedia("(hover:hover) and (pointer:fine)").matches;
var splashOn=document.documentElement.classList.contains("sp-lock");
var base=splashOn?2.6:0.1; // titulli fillon pasi mbyllet splash-i

/* 1. Titulli i hero: fjalë me maskë */
var h1=document.querySelector("h1.big");
if(h1&&!reduce){
  h1.style.setProperty("--base",base+"s");
  var d=0;
  Array.prototype.slice.call(h1.childNodes).forEach(function(n){
    if(n.nodeType===3){
      var frag=document.createDocumentFragment();
      n.textContent.split(/(\s+)/).forEach(function(t){
        if(!t)return;
        if(/^\s+$/.test(t)){frag.appendChild(document.createTextNode(" "));return}
        var w=document.createElement("span");w.className="w";var s=document.createElement("span");s.textContent=t;s.style.setProperty("--d",d++);w.appendChild(s);frag.appendChild(w);
      });
      n.parentNode.replaceChild(frag,n);
    }else if(n.nodeType===1&&n.classList.contains("sig")){
      n.classList.add("w2");n.style.setProperty("--d",d++);
    }
  });
  var tag=document.querySelector(".tag");if(tag)tag.style.setProperty("--base",base+"s");
}

/* 2. Hyrje në scroll */
var targets=[".lead",".stats",".card",".how .head",".step",".cta .eyebrow",".cta h2",".cta .btn","#mine"];
var els=[];
targets.forEach(function(sel){document.querySelectorAll(sel).forEach(function(e,i){e.classList.add("rv");if(sel===".card")e.classList.add("from-r");e.style.setProperty("--rd",(sel===".step"?i*.12:(sel===".lead"?.1:(sel===".stats"?.2:0)))+"s");els.push(e)})});
if("IntersectionObserver" in window&&!reduce){
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){setTimeout(function(){e.target.classList.add("in")},splashOn&&e.target.getBoundingClientRect().top<innerHeight?2400:0);io.unobserve(e.target)}})},{threshold:.12,rootMargin:"0px 0px -6% 0px"});
  els.forEach(function(e){io.observe(e)});
}else els.forEach(function(e){e.classList.add("in")});

/* 3. Numërues për "200 GB" */
document.querySelectorAll(".stats p:first-child").forEach(function(p){
  var m=p.textContent.match(/^(\d+)(\s*GB)$/);if(!m||reduce)return;
  var to=+m[1],suffix=m[2],run=false;
  p.textContent="0"+suffix;
  var o=new IntersectionObserver(function(es){if(es[0].isIntersecting&&!run){run=true;var t0=performance.now()+(splashOn?2800:300);(function f(t){var k=Math.min(Math.max((t-t0)/1400,0),1);p.textContent=Math.round(to*(1-Math.pow(1-k,4)))+suffix;if(k<1)requestAnimationFrame(f)})(performance.now())}},{threshold:.5});
  o.observe(p);
});

if(reduce)return;

/* 4. Shirit progresi + header që fshihet */
var bar=document.createElement("div");bar.className="fx-progress";document.body.appendChild(bar);
var hdr=document.querySelector("header.top"),lastY=0,ticking=false;
function onScroll(){
  var y=scrollY,h=document.documentElement.scrollHeight-innerHeight;
  bar.style.transform="scaleX("+(h>0?y/h:0)+")";
  if(hdr){hdr.classList.toggle("hide",y>lastY&&y>200);}
  lastY=y;
  orbs.forEach(function(o){o.el.style.transform="translate3d(0,"+(y*o.k)+"px,0)"});
  ticking=false;
}
addEventListener("scroll",function(){if(!ticking){ticking=true;requestAnimationFrame(onScroll)}},{passive:true});

/* 5. Orbe parallax + kanavë me grimca (hero) */
var hero=document.querySelector(".hero"),orbs=[];
if(hero){
  [{c:"#ff4b33",s:"28rem",l:"-8rem",t:"-6rem",k:.25},{c:"#7a2cff",s:"22rem",l:"60%",t:"20%",k:-.12}].forEach(function(o){
    var e=document.createElement("div");e.className="fx-orb";e.style.cssText="width:"+o.s+";height:"+o.s+";left:"+o.l+";top:"+o.t+";background:"+o.c;hero.insertBefore(e,hero.firstChild);orbs.push({el:e,k:o.k});
  });
  var cv=document.createElement("canvas");cv.className="fx-canvas";hero.insertBefore(cv,hero.firstChild);
  var cx=cv.getContext("2d"),W,H,P=[],mouse={x:-999,y:-999},dpr=Math.min(devicePixelRatio||1,2),vis=true;
  function size(){var r=hero.getBoundingClientRect();W=r.width;H=r.height;cv.width=W*dpr;cv.height=H*dpr;cx.setTransform(dpr,0,0,dpr,0,0);
    var n=Math.min(70,Math.floor(W*H/16000));P=[];for(var i=0;i<n;i++)P.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.35,vy:(Math.random()-.5)*.35,r:Math.random()*1.8+.6})}
  size();addEventListener("resize",size);
  hero.addEventListener("mousemove",function(e){var r=hero.getBoundingClientRect();mouse.x=e.clientX-r.left;mouse.y=e.clientY-r.top});
  hero.addEventListener("mouseleave",function(){mouse.x=mouse.y=-999});
  new IntersectionObserver(function(es){vis=es[0].isIntersecting}).observe(hero);
  (function loop(){
    requestAnimationFrame(loop);if(!vis||document.hidden)return;
    cx.clearRect(0,0,W,H);
    for(var i=0;i<P.length;i++){var p=P[i];
      p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;
      var dx=p.x-mouse.x,dy=p.y-mouse.y,dm=Math.sqrt(dx*dx+dy*dy);
      if(dm<120){p.x+=dx/dm*1.6;p.y+=dy/dm*1.6}
      cx.fillStyle="rgba(255,122,92,.7)";cx.beginPath();cx.arc(p.x,p.y,p.r,0,6.283);cx.fill();
      for(var j=i+1;j<P.length;j++){var q=P[j],ax=p.x-q.x,ay=p.y-q.y,dd=ax*ax+ay*ay;
        if(dd<110*110){cx.strokeStyle="rgba(255,75,51,"+(.22*(1-Math.sqrt(dd)/110))+")";cx.lineWidth=.8;cx.beginPath();cx.moveTo(p.x,p.y);cx.lineTo(q.x,q.y);cx.stroke()}}
      if(dm<160){cx.strokeStyle="rgba(255,75,51,"+(.45*(1-dm/160))+")";cx.beginPath();cx.moveTo(p.x,p.y);cx.lineTo(mouse.x,mouse.y);cx.stroke()}
    }
  })();
}

if(!fine)return;
/* 6. Drita që ndjek kursorin */
var g=document.createElement("div");g.className="fx-cursor";document.body.appendChild(g);
var gx=0,gy=0,tx=0,ty=0;
addEventListener("mousemove",function(e){tx=e.clientX;ty=e.clientY;g.classList.add("on")});
document.addEventListener("mouseleave",function(){g.classList.remove("on")});
(function m(){gx+=(tx-gx)*.12;gy+=(ty-gy)*.12;g.style.transform="translate("+gx+"px,"+gy+"px)";requestAnimationFrame(m)})();

/* 7. Butona magnetikë */
document.querySelectorAll(".cta .btn,.hero .btn").forEach(function(b){
  b.classList.add("mag");
  b.addEventListener("mousemove",function(e){var r=b.getBoundingClientRect();b.style.transform="translate("+(e.clientX-r.left-r.width/2)*.25+"px,"+(e.clientY-r.top-r.height/2)*.35+"px)"});
  b.addEventListener("mouseleave",function(){b.style.transform=""});
});

/* 8. Tilt 3D te hapat */
document.querySelectorAll(".step").forEach(function(s){
  s.addEventListener("mousemove",function(e){var r=s.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;
    s.style.transform="perspective(800px) rotateY("+((x-.5)*12)+"deg) rotateX("+((.5-y)*12)+"deg) translateZ(6px)";s.style.setProperty("--mx",x*100+"%");s.style.setProperty("--my",y*100+"%")});
  s.addEventListener("mouseleave",function(){s.style.transform=""});
});
})();
