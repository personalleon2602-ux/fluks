import { createHash, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { env } from "cloudflare:workers";
import { DL_CHUNK, addUsed, clearParts, db, deleteChunks, deleteEvents, deleteUpload, getUsed, listParts, partKey, partSizeFor, purgeExpired, videoKey } from "./store.mjs";

const GB = 1024 ** 3;
const MAX_FILE = Number(env.MAX_FILE_GB || 200) * GB;
const UPLOADS_PER_HOUR = Number(env.UPLOADS_PER_HOUR || 0); // 0 = pa limit
const REPORTS_PER_HOUR = Number(env.REPORTS_PER_HOUR || 8);
const REPORT_THRESHOLD = Number(env.REPORT_THRESHOLD || 3);
const DAILY_BYTES_PER_IP = Number(env.DAILY_GB_PER_IP || 0) * GB; // 0 = pa limit
const MAX_TOTAL = Number(env.MAX_TOTAL_GB || 0) * GB; // 0 = pa limit
const TURNSTILE_SITE_KEY = env.TURNSTILE_SITE_KEY || "";
const TURNSTILE_SECRET = env.TURNSTILE_SECRET || "";
const PUBLIC_URL = (env.PUBLIC_URL || "").replace(/\/+$/, "");
const CONTACT_EMAIL = env.CONTACT_EMAIL || "";
const ADMIN_PASSWORD = env.ADMIN_PASSWORD || "";
const TAKEDOWN_HOLD_MS = 24 * 3600 * 1000; // rekordet e hequra mbahen 24 orë për shqyrtim, pastaj fshihen
const TTL_OPTIONS_H = [1, 6, 24, 72, 168]; // orë: 1 orë … 7 ditë
const DEFAULT_TTL_H = 72;
const SALT = env.IP_HASH_SALT || "fluks-default-salt-change-me";
const REASONS = ["child_safety", "violence", "copyright", "privacy", "spam", "other"];
const VIDEO_EXT = /\.(mp4|m4v|mov|webm|mkv|avi|mpg|mpeg|3gp|wmv|flv|ogv|ts)$/i;
const SLUG_RE = /^[a-z0-9]{8,12}$/;
const UUID_RE = /^[0-9a-f-]{36}$/i;

const sha = (v) => createHash("sha256").update(v).digest("hex");
const json = (body, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
const alphabet = "23456789abcdefghjkmnpqrstuvwxyz";
const randStr = (n, a = alphabet) => Array.from(randomBytes(n), (b) => a[b % a.length]).join("");
const readBody = async (req) => { try { return await req.json(); } catch { return null; } };

/** Njoftimet: çdo shikim/shkarkim ruhet si çelës i vogël (pa u përplasur me njëri-tjetrin). */
async function logEvent(slug, type, ip, country) {
  try {
    if (!(await allow(`e-${type}-${sha(SALT + ip + slug)}`, 3))) return;
    const cc = /^[A-Z]{2}$/.test(country || "") ? country : "XX";
    await db().set(`events/${slug}/${Date.now()}-${type === "download" ? "d" : "v"}-${cc}-${randStr(4)}`, "1");
    await logStat(type === "download" ? "d" : "v", ip, country, slug, 0);
  } catch {}
}

/** Statistikat për panelin e pronarit: çelësa të vegjël që NUK fshihen bashkë me videon. */
async function logStat(t, ip, country, slug, size) {
  try {
    const cc = /^[A-Z]{2}$/.test(country || "") ? country : "XX";
    const now = Date.now();
    await db().set(`stats/${new Date(now).toISOString().slice(0, 10)}/${now}-${t}-${cc}-${sha(SALT + "v" + ip).slice(0, 6)}-${slug}-${Math.max(0, Math.floor(size))}`, "1");
  } catch {}
}

/** Kufizues ritmi (ruhet në Blobs, ndaj mban mend mes thirrjeve). */
async function allow(bucketKey, limit) {
  const d = db();
  const key = `meta/rate/${bucketKey}-${Math.floor(Date.now() / 3_600_000)}`;
  const cur = (await d.get(key, { type: "json" }).catch(() => null)) ?? { n: 0, at: Date.now() };
  if (cur.n >= limit) return false;
  await d.setJSON(key, { n: cur.n + 1, at: cur.at });
  return true;
}

/** Kuota ditore e bajteve për IP (ruhet në Blobs). */
async function takeQuota(ipHash, bytes) {
  const d = db();
  const key = `meta/quota/${ipHash}-${new Date().toISOString().slice(0, 10)}`;
  const cur = (await d.get(key, { type: "json" }).catch(() => null)) ?? { bytes: 0, at: Date.now() };
  if (cur.bytes + bytes > DAILY_BYTES_PER_IP) return { ok: false, left: Math.max(0, DAILY_BYTES_PER_IP - cur.bytes) };
  await d.setJSON(key, { bytes: cur.bytes + bytes, at: cur.at });
  return { ok: true };
}

/** Verifikimi Cloudflare Turnstile (aktiv vetëm nëse TURNSTILE_SECRET është vendosur). */
async function turnstileOk(token, ip) {
  if (!TURNSTILE_SECRET) return true;
  if (!token || typeof token !== "string") return false;
  try {
    const r = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ secret: TURNSTILE_SECRET, response: token, remoteip: ip }),
    });
    return !!(await r.json()).success;
  } catch { return false; }
}

function looksLikeVideo(b) {
  if (b.length < 12) return false;
  const s4 = b.subarray(4, 8).toString("latin1");
  const s0 = b.subarray(0, 4).toString("latin1");
  if (s4 === "ftyp" || s4 === "moov" || s4 === "mdat" || s4 === "free" || s4 === "wide") return true; // mp4/mov/3gp
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return true; // webm/mkv
  if (s0 === "RIFF" && b.subarray(8, 12).toString("latin1") === "AVI ") return true;
  if (s0 === "OggS" || s0.startsWith("FLV")) return true;
  if (b[0] === 0 && b[1] === 0 && b[2] === 1 && (b[3] === 0xba || b[3] === 0xb3)) return true; // mpeg
  if (b[0] === 0x30 && b[1] === 0x26 && b[2] === 0xb2 && b[3] === 0x75) return true; // wmv
  if (b[0] === 0x47) return true; // mpeg-ts
  return false;
}

async function init(req, ip) {
  if (await db().get(`meta/ban/${sha(SALT + ip)}`).catch(() => null))
    return json({ error: "Qasja jote për ngarkim është bllokuar." }, 403);
  if (UPLOADS_PER_HOUR > 0 && !(await allow(`u-${sha(SALT + ip)}`, UPLOADS_PER_HOUR)))
    return json({ error: "Ke arritur limitin e ngarkimeve për një orë. Provo sërish më vonë." }, 429);
  const body = await readBody(req);
  if (!body) return json({ error: "Kërkesë e pavlefshme." }, 400);

  const fileName = String(body.fileName ?? "").replace(/[\u0000-\u001f\\/]/g, "_").trim().slice(0, 200) || "video";
  const rawMime = typeof body.mimeType === "string" ? body.mimeType : "";
  const mime = /^video\/[\w.+-]{1,60}$/.test(rawMime) ? rawMime : "video/mp4";
  const size = Math.floor(Number(body.size));
  const dur = Number(body.duration ?? 0);
  const duration = Number.isFinite(dur) && dur > 0 ? Math.round(dur) : null;

  if (!rawMime.startsWith("video/") && !VIDEO_EXT.test(fileName))
    return json({ error: "Pranohen vetëm skedarë video (MP4, MOV, WEBM…)." }, 415);
  if (!Number.isFinite(size) || size <= 0) return json({ error: "Skedari duket i zbrazët." }, 400);
  if (size > MAX_FILE)
    return json({ error: `Videoja tejkalon limitin e lirë prej ${Math.round(MAX_FILE / GB)} GB.` }, 413);

  if (!(await turnstileOk(body.cfToken, ip)))
    return json({ error: "Verifikimi kundër robotëve dështoi. Rifresko faqen dhe provo sërish." }, 403);
  if (MAX_TOTAL > 0 && (await getUsed()) + size > MAX_TOTAL)
    return json({ error: "Ruajtja e faqes është e mbushur përkohësisht. Provo më vonë, kur të skadojnë video të vjetra." }, 507);

  const q = DAILY_BYTES_PER_IP > 0 ? await takeQuota(sha(SALT + ip), size) : { ok: true };
  if (!q.ok)
    return json({ error: `Ke arritur kufirin ditor të ngarkimit (${Math.round(DAILY_BYTES_PER_IP / GB)} GB për ditë). Provo nesër.` }, 429);

  const pwRaw = typeof body.password === "string" ? body.password.trim().slice(0, 100) : "";
  const pwHash = pwRaw ? sha(SALT + "pw" + pwRaw) : null;

  const reqTtl = Number(body.ttlHours);
  const ttlHours = TTL_OPTIONS_H.includes(reqTtl) ? reqTtl : DEFAULT_TTL_H;

  const id = randomUUID();
  const partSize = partSizeFor(size);
  const total = Math.ceil(size / partSize);
  const mpu = await env.BUCKET.createMultipartUpload(videoKey(id), { httpMetadata: { contentType: mime } });
  await db().setJSON(`meta/uploads/${id}`, { id, fileName, mime, size, duration, total, partSize, uploadId: mpu.uploadId, ttlHours, pwHash, uploader: sha(SALT + ip), createdAt: Date.now() });
  await addUsed(size);
  return json({ id, chunkSize: partSize, total });
}

const UP_CACHE = new Map();
async function getUpload(id) {
  let up = UP_CACHE.get(id);
  if (up && Date.now() - up.at < 5 * 60 * 1000) return up;
  const rec = await db().get(`meta/uploads/${id}`, { type: "json" });
  if (!rec) { UP_CACHE.delete(id); return null; }
  if (UP_CACHE.size > 200) UP_CACHE.clear();
  up = { at: Date.now(), ...rec };
  UP_CACHE.set(id, up);
  return up;
}

async function chunk(req, url) {
  const id = url.searchParams.get("id") ?? "";
  const index = Number(url.searchParams.get("index"));
  if (!UUID_RE.test(id)) return json({ error: "Kërkesë e pavlefshme." }, 400);
  try {
    const up = await getUpload(id);
    if (!up) return json({ error: "Sesioni i ngarkimit nuk ekziston më." }, 404);
    if (!Number.isInteger(index) || index < 0 || index >= up.total) return json({ error: "Pjesë e pavlefshme." }, 400);
    const expected = index === up.total - 1 ? up.size - index * up.partSize : up.partSize;
    let body = req.body;
    const len = Number(req.headers.get("content-length"));
    if (!body) return json({ error: "Pjesa është bosh." }, 400);
    if (len) { if (len !== expected) return json({ error: "Madhësia e pjesës nuk përputhet." }, 400); }
    else { body = await req.arrayBuffer(); if (body.byteLength !== expected) return json({ error: "Madhësia e pjesës nuk përputhet." }, 400); }
    const mpu = env.BUCKET.resumeMultipartUpload(videoKey(id), up.uploadId);
    const part = await mpu.uploadPart(index + 1, body); // dërgohet drejt R2 si rrjedhë (pa e mbajtur në memorie)
    await env.BUCKET.put(partKey(id, index), "", { customMetadata: { etag: part.etag } });
    return json({ ok: true });
  } catch (e) {
    console.error("chunk failed", id, index, e);
    const msg = String(e?.message ?? e);
    if (/does not exist|NoSuchUpload|10024/i.test(msg)) { UP_CACHE.delete(id); return json({ error: "Sesioni i ngarkimit nuk ekziston më." }, 404); }
    return new Response(JSON.stringify({ error: "Ruajtja e pjesës dështoi përkohësisht.", detail: msg.slice(0, 200) }), {
      status: 503,
      headers: { "content-type": "application/json", "cache-control": "no-store", "retry-after": "3" },
    });
  }
}

/** Cilat pjesë janë ngarkuar tashmë (për rifillim pas ndërprerjes). */
async function status(url) {
  const id = url.searchParams.get("id") ?? "";
  if (!UUID_RE.test(id)) return json({ error: "Kërkesë e pavlefshme." }, 400);
  const up = await getUpload(id);
  if (!up) return json({ error: "Sesioni i ngarkimit nuk ekziston më." }, 404);
  const have = (await listParts(id)).map((p) => p.index);
  return json({ id, total: up.total, chunkSize: up.partSize, size: up.size, have });
}

async function complete(req, ip, country) {
  const b = await readBody(req);
  if (!b || !UUID_RE.test(String(b.id))) return json({ error: "Kërkesë e pavlefshme." }, 400);
  const d = db();
  const up = await d.get(`meta/uploads/${b.id}`, { type: "json" });
  if (!up) return json({ error: "Sesioni i ngarkimit nuk ekziston më." }, 404);

  const parts = await listParts(up.id);
  if (parts.length !== up.total) return json({ error: "Ngarkimi nuk ka mbaruar ende." }, 409);
  parts.sort((x, y) => x.index - y.index);
  const mpu = env.BUCKET.resumeMultipartUpload(videoKey(up.id), up.uploadId);
  const obj = await mpu.complete(parts.map((p) => ({ partNumber: p.index + 1, etag: p.etag })));
  UP_CACHE.delete(up.id);

  const head = await env.BUCKET.get(videoKey(up.id), { range: { offset: 0, length: 64 } });
  const first = head ? Buffer.from(await head.arrayBuffer()) : null;
  if (!first || obj.size !== up.size || !looksLikeVideo(first)) {
    await deleteChunks(up.id); await clearParts(up.id); await d.delete(`meta/uploads/${up.id}`);
    return json({ error: "Ky skedar nuk duket si video e vlefshme." }, 415);
  }
  await clearParts(up.id);

  const slug = randStr(8);
  const deleteToken = randStr(32, alphabet + "ABCDEFGHJKLMNPQRSTUVWXYZ");
  const rec = {
    id: up.id, slug, fileName: up.fileName, mime: up.mime, size: up.size, duration: up.duration,
    createdAt: Date.now(), uploader: up.uploader || null, ttlHours: up.ttlHours || DEFAULT_TTL_H, expiresAt: Date.now() + (up.ttlHours || DEFAULT_TTL_H) * 3600 * 1000, deleteHash: sha(deleteToken),
    views: 0, reporters: [], reports: [], takedown: false, pwHash: up.pwHash || null,
  };
  await d.setJSON(`meta/videos/${slug}`, rec);
  await d.delete(`meta/uploads/${up.id}`);
  await logStat("u", ip, country, slug, up.size);
  return json({ slug, url: `/v/${slug}`, fileName: rec.fileName, expiresAt: new Date(rec.expiresAt).toISOString(), deleteToken });
}

async function loadVideo(slug) {
  if (!SLUG_RE.test(slug)) return { res: json({ error: "not_found" }, 404) };
  const rec = await db().get(`meta/videos/${slug}`, { type: "json" });
  if (!rec) return { res: json({ error: "not_found" }, 404) };
  if (rec.takedown) return { res: json({ error: "removed" }, 410) };
  if (Date.now() > rec.expiresAt) return { res: json({ error: "expired" }, 410) };
  return { rec };
}

async function viewVideo(slug, req, ip, country) {
  const { rec, res } = await loadVideo(slug);
  if (res) return res;
  if (rec.pwHash) {
    const given = req.headers.get("x-video-pass") || "";
    if (!given) return json({ error: "password" }, 401);
    if (!(await allow(`pw-${sha(SALT + ip + slug)}`, 30))) return json({ error: "Shumë përpjekje. Provo më vonë." }, 429);
    const a = Buffer.from(sha(SALT + "pw" + given)), c = Buffer.from(rec.pwHash);
    if (a.length !== c.length || !timingSafeEqual(a, c)) return json({ error: "password" }, 401);
  }
  if (req.headers.get("x-owner") !== "1") await logEvent(slug, "view", ip, country);
  rec.views = (rec.views || 0) + 1;
  await db().setJSON(`meta/videos/${slug}`, rec).catch(() => {});
  return json({
    fileName: rec.fileName, mimeType: rec.mime, size: rec.size, duration: rec.duration,
    views: rec.views, expiresAt: new Date(rec.expiresAt).toISOString(),
    stream: `/api/video/${slug}/stream${rec.pwHash ? "?k=" + sha(rec.pwHash + slug).slice(0, 32) : ""}`, chunk: DL_CHUNK,
  });
}

/** Shërben videon me Range, drejtpërdrejt nga R2 (rrjedhë, pa kufi pjesësh). */
async function streamVideo(req, slug) {
  const { rec, res } = await loadVideo(slug);
  if (res) return res;
  if (rec.pwHash && new URL(req.url).searchParams.get("k") !== sha(rec.pwHash + slug).slice(0, 32)) return new Response("Kërkohet fjalëkalimi", { status: 403 });
  const size = rec.size;
  const hdr = (req.headers.get("range") || "").trim();
  const m = /^bytes=(\d*)-(\d*)$/.exec(hdr);
  let start = 0, end = size - 1;
  if (m && (m[1] || m[2])) {
    if (!m[1]) { start = Math.max(0, size - Number(m[2])); }
    else { start = Number(m[1]); if (m[2]) end = Math.min(Number(m[2]), size - 1); }
  }
  if (!Number.isFinite(start) || start >= size || start > end)
    return new Response(null, { status: 416, headers: { "content-range": `bytes */${size}` } });
  const length = end - start + 1;
  const o = await env.BUCKET.get(videoKey(rec.id), { range: { offset: start, length } });
  if (!o) return new Response("Videoja mungon", { status: 404 });
  const ranged = !!(m && (m[1] || m[2]));
  const headers = {
    "content-type": rec.mime, "accept-ranges": "bytes", "content-length": String(length),
    "cache-control": "private, max-age=3600", "x-content-type-options": "nosniff",
  };
  if (ranged) headers["content-range"] = `bytes ${start}-${end}/${size}`;
  return new Response(o.body, { status: ranged ? 206 : 200, headers });
}

/** Linku vdes menjëherë; rekordi mbetet derisa të fshihen të gjitha pjesët. */
async function eventVideo(req, slug, ip, country) {
  const b = await readBody(req);
  if (!b || b.type !== "download") return json({ error: "Kërkesë e pavlefshme." }, 400);
  const { res } = await loadVideo(slug);
  if (res) return res;
  await logEvent(slug, "download", ip, country);
  return json({ ok: true });
}

/** Njoftimet për zilen: kthen ngjarjet e reja për videot e mia (vërtetohet me kodin e fshirjes). */
async function notifs(req, ip) {
  const b = await readBody(req);
  if (!b || !Array.isArray(b.items)) return json({ error: "Kërkesë e pavlefshme." }, 400);
  if (!(await allow(`n-${sha(SALT + ip)}`, 900))) return json({ error: "Shumë kërkesa." }, 429);
  const since = Number(b.since) || 0, d = db();
  const events = [], counts = {};
  const items = b.items.slice(0, 100).filter((it) => it && SLUG_RE.test(String(it.slug)) && typeof it.token === "string");
  for (let i = 0; i < items.length; i += 10) {
    await Promise.all(items.slice(i, i + 10).map(async (it) => {
      const rec = await d.get(`meta/videos/${it.slug}`, { type: "json" }).catch(() => null);
      if (!rec || rec.takedown) return;
      const a = Buffer.from(sha(it.token)), c = Buffer.from(rec.deleteHash);
      if (a.length !== c.length || !timingSafeEqual(a, c)) return;
      const cnt = { v: 0, d: 0 };
      for await (const page of d.list({ prefix: `events/${it.slug}/`, paginate: true })) {
        for (const { key } of page.blobs) {
          const m = /^events\/[a-z0-9]+\/(\d+)-([vd])-([A-Z]{2})-\w+$/.exec(key);
          if (!m) continue;
          cnt[m[2]]++;
          if (Number(m[1]) > since) events.push({ id: key.slice(key.lastIndexOf("/") + 1), slug: it.slug, type: m[2] === "d" ? "download" : "view", at: Number(m[1]), cc: m[3] });
        }
      }
      counts[it.slug] = cnt;
    }));
  }
  events.sort((x, y) => y.at - x.at);
  return json({ events: events.slice(0, 200), counts, now: Date.now() });
}

async function removeVideo(rec, budget = 15000) {
  rec.takedown = true; rec.expiresAt = 0; rec.takedownAt = rec.takedownAt || Date.now();
  await db().setJSON(`meta/videos/${rec.slug}`, rec);
  if (await deleteChunks(rec.id, budget)) { await db().delete(`meta/videos/${rec.slug}`); await deleteEvents(rec.slug); await addUsed(-rec.size); }
}

async function deleteVideo(req, slug) {
  const b = await readBody(req);
  if (!SLUG_RE.test(slug) || !b || typeof b.token !== "string") return json({ error: "Kërkesë e pavlefshme." }, 400);
  const d = db();
  const rec = await d.get(`meta/videos/${slug}`, { type: "json" });
  if (!rec) return json({ error: "Videoja nuk ekziston më." }, 404);
  if (typeof rec.deleteHash !== "string") return json({ error: "Kjo video nuk mund të fshihet me kod." }, 403);
  const a = Buffer.from(sha(b.token)), c = Buffer.from(rec.deleteHash);
  if (a.length !== c.length || !timingSafeEqual(a, c)) return json({ error: "Kodi i fshirjes është i pasaktë." }, 403);

  // Hapi 1: linku vdes menjëherë (shënohet si e hequr).
  let marked = false, gone = false, lastErr = "";
  try {
    rec.takedown = true; rec.expiresAt = 0; rec.takedownAt = rec.takedownAt || Date.now();
    await d.setJSON(`meta/videos/${slug}`, rec);
    marked = true;
  } catch (e) { console.error("delete:mark", e); lastErr = "mark: " + (e && e.message); }
  // Hapi 2: pastrimi i pjesëve (provohet; çka mbetet e pastron cleanup-i çdo orë).
  try {
    if (await deleteChunks(rec.id, 6000)) {
      await d.delete(`meta/videos/${slug}`); gone = true;
      try { await deleteEvents(slug); } catch (e) { console.error("delete:events", e); }
      try { await addUsed(-(rec.size || 0)); } catch (e) { console.error("delete:used", e); }
    }
  } catch (e) { console.error("delete:chunks", e); lastErr = lastErr || "chunks: " + (e && e.message); }
  if (!marked && !gone) return json({ error: "Fshirja dështoi (" + String(lastErr).slice(0, 160) + "). Provo sërish." }, 500);
  return json({ ok: true });
}

async function reportVideo(req, slug, ip) {
  const b = await readBody(req);
  if (!SLUG_RE.test(slug) || !b || !REASONS.includes(b.reason)) return json({ error: "Zgjidh një arsye." }, 400);
  const rhash = sha(SALT + ip);
  if (!(await allow(`r-${rhash}`, REPORTS_PER_HOUR))) return json({ error: "Shumë raportime. Provo më vonë." }, 429);
  const d = db();
  const rec = await d.get(`meta/videos/${slug}`, { type: "json" });
  if (!rec) return json({ error: "Videoja nuk ekziston më." }, 404);
  if (!rec.reporters.includes(rhash)) {
    rec.reporters.push(rhash);
    rec.reports.push({ reason: b.reason, details: String(b.details ?? "").slice(0, 1000), at: Date.now() });
    if (b.reason === "child_safety" || rec.reporters.length >= REPORT_THRESHOLD) {
      if (!rec.takedown) rec.takedownAt = Date.now();
      rec.takedown = true;
    }
    await d.setJSON(`meta/videos/${slug}`, rec);
  }
  return json({ ok: true });
}

/** ---- Paneli i administratorit (aktiv vetëm nëse ADMIN_PASSWORD është vendosur) ---- */
async function loadAll(d, budgetMs = 20000) {
  const t0 = Date.now(), keys = [];
  for await (const page of d.list({ prefix: "meta/videos/", paginate: true })) for (const b of page.blobs) keys.push(b.key);
  const items = [];
  let partial = false;
  for (let i = 0; i < keys.length; i += 25) {
    if (Date.now() - t0 > budgetMs) { partial = true; break; }
    const recs = await Promise.all(keys.slice(i, i + 25).map((k) => d.get(k, { type: "json" }).catch(() => null)));
    for (const r of recs) if (r) items.push(r);
  }
  return { items, partial };
}

const STAT_RE = /^stats\/(\d{4}-\d{2}-\d{2})\/(\d+)-([uvd])-([A-Z]{2})-([0-9a-f]{6})-([a-z0-9]*)-(\d+)$/;

async function analytics(d, url) {
  const days = Math.min(90, Math.max(1, Number(url.searchParams.get("days")) || 30));
  const now = Date.now(), t0 = now;
  const dayKeys = [];
  for (let i = 0; i < days * 2; i++) dayKeys.push(new Date(now - i * 86400000).toISOString().slice(0, 10));
  const curDays = new Set(dayKeys.slice(0, days));
  const evs = [];
  let partial = false;
  for (let i = 0; i < dayKeys.length; i += 12) {
    if (Date.now() - t0 > 12000) { partial = true; break; }
    await Promise.all(dayKeys.slice(i, i + 12).map(async (day) => {
      for await (const page of d.list({ prefix: `stats/${day}/`, paginate: true })) {
        for (const { key } of page.blobs) {
          const m = STAT_RE.exec(key);
          if (m) evs.push({ day: m[1], at: Number(m[2]), t: m[3], cc: m[4], ip: m[5], slug: m[6], size: Number(m[7]) });
        }
      }
    }));
  }
  const { items: recs } = await loadAll(d, 8000);
  const name = {};
  const state = { total: recs.length, active: 0, expired: 0, removed: 0, bytes: 0, viewsAllTime: 0 };
  const ttl = {}, reasons = {};
  let reportsTotal = 0;
  for (const r of recs) {
    name[r.slug] = r.fileName;
    if (r.takedown) state.removed++; else if (now > r.expiresAt) state.expired++; else state.active++;
    state.bytes += r.size || 0; state.viewsAllTime += r.views || 0;
    ttl[r.ttlHours || 72] = (ttl[r.ttlHours || 72] || 0) + 1;
    for (const x of r.reports || []) { reportsTotal++; reasons[x.reason] = (reasons[x.reason] || 0) + 1; }
  }
  const blank = () => ({ u: 0, v: 0, d: 0, bytes: 0, uniq: new Set() });
  const cur = blank(), prev = blank();
  const byDay = {};
  const hours = Array(24).fill(0);
  const vc = {}, uc = {}, top = {};
  const buckets = [["< 50 MB", 5e7], ["50–500 MB", 5e8], ["0.5–5 GB", 5e9], ["5–50 GB", 5e10], ["> 50 GB", Infinity]].map(([l, max]) => ({ label: l, max, n: 0 }));
  let live = 0;
  for (const e of evs) {
    const isCur = curDays.has(e.day), tot = isCur ? cur : prev;
    tot[e.t]++;
    if (e.t === "u") tot.bytes += e.size;
    else tot.uniq.add(e.ip);
    if (!isCur) continue;
    const row = (byDay[e.day] ||= { u: 0, v: 0, d: 0 });
    row[e.t]++;
    if (now - e.at < 5 * 60 * 1000) live++;
    hours[new Date(e.at).getUTCHours()]++;
    if (e.t === "u") {
      uc[e.cc] = (uc[e.cc] || 0) + 1;
      const b = buckets.find((x) => e.size < x.max); if (b) b.n++;
    } else {
      const c = (vc[e.cc] ||= { cc: e.cc, v: 0, d: 0, ips: new Set() });
      c[e.t]++; c.ips.add(e.ip);
      const t = (top[e.slug] ||= { slug: e.slug, v: 0, d: 0 });
      t[e.t]++;
    }
  }
  const series = [];
  for (let i = days - 1; i >= 0; i--) { const day = dayKeys[i]; series.push({ day, ...(byDay[day] || { u: 0, v: 0, d: 0 }) }); }
  evs.sort((a, b) => b.at - a.at);
  const fin = (x) => ({ u: x.u, v: x.v, d: x.d, bytes: x.bytes, uniq: x.uniq.size });
  return {
    days, partial, generatedAt: now, series, cur: fin(cur), prev: fin(prev), hours, live,
    countries: Object.values(vc).map((c) => ({ cc: c.cc, v: c.v, d: c.d, uniq: c.ips.size })).sort((a, b) => b.v + b.d - (a.v + a.d)).slice(0, 12),
    uploaders: Object.entries(uc).map(([cc, n]) => ({ cc, n })).sort((a, b) => b.n - a.n).slice(0, 8),
    top: Object.values(top).sort((a, b) => b.v + b.d - (a.v + a.d)).slice(0, 10).map((t) => ({ ...t, name: name[t.slug] || null })),
    recent: evs.slice(0, 40).map((e) => ({ t: e.t, cc: e.cc, slug: e.slug, at: e.at, size: e.size, name: name[e.slug] || null })),
    sizes: buckets.map(({ label, n }) => ({ label, n })),
    ttl: Object.entries(ttl).map(([h, n]) => ({ h: Number(h), n })).sort((a, b) => a.h - b.h),
    state, reports: { total: reportsTotal, reasons }, storage: { used: await getUsed(), max: MAX_TOTAL },
  };
}

async function admin(req, p, ip) {
  if (!ADMIN_PASSWORD) return json({ error: "Paneli është çaktivizuar (vendos ADMIN_PASSWORD)." }, 404);
  if (!(await allow(`a-${sha(SALT + ip)}`, 120))) return json({ error: "Shumë përpjekje. Provo më vonë." }, 429);
  const pw = req.headers.get("x-admin-password") || "";
  const a = Buffer.from(sha(pw)), c = Buffer.from(sha(ADMIN_PASSWORD));
  if (!timingSafeEqual(a, c)) return json({ error: "Fjalëkalim i gabuar." }, 401);
  const d = db();

  if (req.method === "GET" && p[1] === "analytics") return json(await analytics(d, new URL(req.url)));

  if (req.method === "GET" && p[1] === "data") {
    const { items: recs, partial } = await loadAll(d);
    const now = Date.now();
    const sum = { videos: recs.length, active: 0, expired: 0, takedown: 0, reported: 0, views: 0, bytes: 0, uploads: 0, uploadBytes: 0, partial };
    const items = recs.map((r) => {
      const expired = now > r.expiresAt;
      if (r.takedown) sum.takedown++; else if (expired) sum.expired++; else sum.active++;
      if (r.reports && r.reports.length) sum.reported++;
      sum.views += r.views || 0; sum.bytes += r.size || 0;
      return {
        slug: r.slug, fileName: r.fileName, size: r.size, views: r.views || 0, takedown: !!r.takedown, expired,
        createdAt: r.createdAt, expiresAt: r.expiresAt, takedownAt: r.takedownAt || null,
        uploader: r.uploader || null, reports: r.reports || [],
      };
    });
    for await (const page of d.list({ prefix: "meta/uploads/", paginate: true })) {
      for (const { key } of page.blobs) {
        const up = await d.get(key, { type: "json" }).catch(() => null);
        if (up) { sum.uploads++; sum.uploadBytes += up.size || 0; }
      }
    }
    const bans = [];
    for await (const page of d.list({ prefix: "meta/ban/", paginate: true })) {
      for (const { key } of page.blobs) {
        const r = await d.get(key, { type: "json" }).catch(() => null);
        bans.push({ hash: key.slice("meta/ban/".length), at: r?.at ?? null, note: r?.note ?? "" });
      }
    }
    items.sort((x, y) => y.createdAt - x.createdAt);
    return json({
      items, summary: sum, bans,
      stats: { used: await getUsed(), max: MAX_TOTAL },
      config: {
        maxFileGB: MAX_FILE / GB, maxTotalGB: MAX_TOTAL / GB, dailyGBPerIP: DAILY_BYTES_PER_IP / GB, uploadsPerHour: UPLOADS_PER_HOUR,
        reportThreshold: REPORT_THRESHOLD, ttlOptionsHours: TTL_OPTIONS_H, turnstile: !!TURNSTILE_SECRET,
        contactEmail: CONTACT_EMAIL, publicUrl: PUBLIC_URL,
      },
    });
  }

  if (req.method === "POST" && p[1] === "action") {
    const b = await readBody(req);
    if (!b) return json({ error: "Kërkesë e pavlefshme." }, 400);

    if (b.action === "purge") return json({ ok: true, ...(await purgeExpired(20000)) });

    if (b.action === "unban") {
      if (!/^[0-9a-f]{64}$/.test(String(b.hash))) return json({ error: "Kërkesë e pavlefshme." }, 400);
      await d.delete(`meta/ban/${b.hash}`);
      return json({ ok: true });
    }

    if (b.action === "remove" && Array.isArray(b.slugs)) {
      const t0 = Date.now();
      let done = 0;
      for (const slug of b.slugs.slice(0, 200)) {
        if (!SLUG_RE.test(String(slug))) continue;
        const left = 24000 - (Date.now() - t0);
        if (left < 3000) return json({ ok: true, done, partial: true });
        const rec = await d.get(`meta/videos/${slug}`, { type: "json" });
        if (rec) { await removeVideo(rec, left - 2000); done++; }
      }
      return json({ ok: true, done });
    }

    if (!SLUG_RE.test(String(b.slug))) return json({ error: "Kërkesë e pavlefshme." }, 400);
    const rec = await d.get(`meta/videos/${b.slug}`, { type: "json" });
    if (!rec) return json({ error: "Videoja nuk ekziston më." }, 404);
    if (b.action === "remove") { await removeVideo(rec); return json({ ok: true }); }
    if (b.action === "restore") {
      rec.takedown = false; rec.takedownAt = null; rec.reports = []; rec.reporters = [];
      await d.setJSON(`meta/videos/${b.slug}`, rec);
      return json({ ok: true });
    }
    if (b.action === "extend") {
      const h = Number(b.hours);
      if (!Number.isFinite(h) || h < 1 || h > 720) return json({ error: "Orë të pavlefshme (1–720)." }, 400);
      if (rec.takedown) return json({ error: "Videoja është e hequr; rikthe fillimisht." }, 409);
      rec.expiresAt = Date.now() + h * 3600 * 1000;
      await d.setJSON(`meta/videos/${b.slug}`, rec);
      return json({ ok: true, expiresAt: rec.expiresAt });
    }
    if (b.action === "ban") {
      if (!rec.uploader) return json({ error: "Ky rekord nuk ka identifikues ngarkuesi (video e vjetër)." }, 409);
      await d.setJSON(`meta/ban/${rec.uploader}`, { at: Date.now(), note: String(b.note ?? rec.fileName).slice(0, 200) });
      if (b.removeAll) {
        const { items } = await loadAll(d, 12000);
        const t0 = Date.now(); let n = 0;
        for (const r of items) {
          if (r.uploader !== rec.uploader) continue;
          const left = 22000 - (Date.now() - t0);
          if (left < 3000) break;
          await removeVideo(r, left - 2000); n++;
        }
        return json({ ok: true, removed: n });
      }
      return json({ ok: true });
    }
    return json({ error: "Veprim i panjohur." }, 400);
  }
  return json({ error: "Nuk u gjet" }, 404);
}

export default async (req, context) => {
  try {
    const url = new URL(req.url);
    const ip = context?.ip || "unknown";
    const p = url.pathname.replace(/^\/api\//, "").replace(/\/+$/, "").split("/");
    const m = req.method;
    const country = context?.geo?.country?.code || "";
    if (p[0] === "admin") return await admin(req, p, ip);
    if (m === "POST" && p[0] === "notifs") return await notifs(req, ip);
    if (m === "GET" && p[0] === "health") return json({ ok: true, contactEmail: CONTACT_EMAIL, publicUrl: PUBLIC_URL, turnstileSiteKey: TURNSTILE_SECRET ? TURNSTILE_SITE_KEY : "", maxTotalGB: MAX_TOTAL / GB, dailyGBPerIP: DAILY_BYTES_PER_IP / GB, storage: "cloudflare-r2", maxFileGB: MAX_FILE / GB, ttlOptionsHours: TTL_OPTIONS_H });
    if (m === "POST" && p[0] === "upload" && p[1] === "init") return await init(req, ip);
    if (m === "GET" && p[0] === "upload" && p[1] === "status") return await status(url);
    if (m === "PUT" && p[0] === "upload" && p[1] === "chunk") return await chunk(req, url);
    if (m === "POST" && p[0] === "upload" && p[1] === "complete") return await complete(req, ip, country);
    if (p[0] === "video" && p[1]) {
      if (m === "GET" && p.length === 2) return await viewVideo(p[1], req, ip, country);
      if (m === "GET" && p[2] === "stream") return await streamVideo(req, p[1]);
      if (m === "POST" && p[2] === "delete") return await deleteVideo(req, p[1]);
      if (m === "POST" && p[2] === "event") return await eventVideo(req, p[1], ip, country);
      if (m === "POST" && p[2] === "report") return await reportVideo(req, p[1], ip);
    }
    return json({ error: "Nuk u gjet" }, 404);
  } catch (e) {
    console.error(e);
    return json({ error: "Gabim i brendshëm. Provo sërish." }, 500);
  }
};
