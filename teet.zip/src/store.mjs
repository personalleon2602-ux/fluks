import { env } from "cloudflare:workers";

/** Përshtatës i vogël mbi R2 me të njëjtën sjellje si Netlify Blobs (get/set/setJSON/delete/list). */
const all = async (prefix, onPage) => {
  let cursor;
  do {
    const r = await env.BUCKET.list({ prefix, cursor, limit: 1000 });
    await onPage(r.objects);
    cursor = r.truncated ? r.cursor : undefined;
  } while (cursor);
};

const adapter = {
  async get(key, opts) {
    const o = await env.BUCKET.get(key);
    if (!o) return null;
    if (opts?.type === "json") return await o.json();
    if (opts?.type === "arrayBuffer") return await o.arrayBuffer();
    return await o.text();
  },
  async set(key, v) { await env.BUCKET.put(key, v); },
  async setJSON(key, v) { await env.BUCKET.put(key, JSON.stringify(v)); },
  async delete(key) { await env.BUCKET.delete(key); },
  list(opts) {
    const prefix = opts?.prefix ?? "";
    if (opts?.paginate) {
      return (async function* () {
        let cursor;
        do {
          const r = await env.BUCKET.list({ prefix, cursor, limit: 1000 });
          yield { blobs: r.objects.map((o) => ({ key: o.key })) };
          cursor = r.truncated ? r.cursor : undefined;
        } while (cursor);
      })();
    }
    return (async () => {
      const blobs = [];
      await all(prefix, (objs) => { for (const o of objs) blobs.push({ key: o.key }); });
      return { blobs };
    })();
  },
};
export const db = () => adapter;

/** Skedari i videos ruhet si një objekt R2 i vetëm (multipart). */
export const videoKey = (id) => `videos/${id}`;
export const partKey = (id, i) => `meta/parts/${id}/${String(i).padStart(6, "0")}`;

/** Madhësia e pjesës: min. 16 MB, dhe aq e madhe sa të mos kalohen 9000 pjesë (kufiri i R2 është 10,000). */
export const partSizeFor = (size) => Math.max(16 * 1024 * 1024, Math.ceil(size / 9000 / 1048576) * 1048576);
export const DL_CHUNK = 8 * 1024 * 1024; // sa merr shkarkimi në çdo kërkesë Range

export async function listParts(id) {
  const parts = [];
  let cursor;
  do {
    const r = await env.BUCKET.list({ prefix: `meta/parts/${id}/`, cursor, limit: 1000, include: ["customMetadata"] });
    for (const o of r.objects) parts.push({ index: Number(o.key.slice(o.key.lastIndexOf("/") + 1)), etag: o.customMetadata?.etag });
    cursor = r.truncated ? r.cursor : undefined;
  } while (cursor);
  return parts;
}

async function deleteKeys(prefix) {
  await all(prefix, async (objs) => {
    for (let i = 0; i < objs.length; i += 1000) await env.BUCKET.delete(objs.slice(i, i + 1000).map((o) => o.key));
  });
}
export const clearParts = (id) => deleteKeys(`meta/parts/${id}/`);

/** Fshin videon e plotë (objektin). */
export async function deleteChunks(id) {
  await env.BUCKET.delete(videoKey(id));
  return true;
}

/** Fshin një ngarkim të papërfunduar (anulon multipart dhe pjesët e shënuara). */
export async function deleteUpload(up) {
  try { if (up.uploadId) await env.BUCKET.resumeMultipartUpload(videoKey(up.id), up.uploadId).abort(); } catch {}
  await clearParts(up.id);
  await env.BUCKET.delete(videoKey(up.id)).catch(() => {});
  return true;
}

export async function getUsed() {
  const r = await adapter.get("meta/stats", { type: "json" }).catch(() => null);
  return r?.bytes ?? 0;
}
export async function addUsed(delta) {
  const cur = await getUsed();
  await adapter.setJSON("meta/stats", { bytes: Math.max(0, cur + delta), at: Date.now() }).catch(() => {});
}

export async function deleteEvents(slug) {
  try { await deleteKeys(`events/${slug}/`); } catch {}
}

/** Fshin videot e skaduara/të hequra (>24h) dhe sesionet e braktisura (>72h). */
export async function purgeExpired(budgetMs = 20000) {
  const d = adapter, t0 = Date.now(), now = t0;
  const out = { videos: 0, uploads: 0, freed: 0, partial: false };
  const left = () => budgetMs - (Date.now() - t0);
  for await (const page of d.list({ prefix: "meta/videos/", paginate: true })) {
    for (const { key } of page.blobs) {
      if (left() < 2000) { out.partial = true; break; }
      const rec = await d.get(key, { type: "json" }).catch(() => null);
      if (rec && (now > rec.expiresAt || (rec.takedown && now - (rec.takedownAt ?? 0) > 24 * 3600 * 1000))) {
        await deleteChunks(rec.id); await d.delete(key); await deleteEvents(rec.slug); out.videos++; out.freed += rec.size || 0;
      }
    }
    if (out.partial) break;
  }
  if (!out.partial) {
    for await (const page of d.list({ prefix: "meta/uploads/", paginate: true })) {
      for (const { key } of page.blobs) {
        if (left() < 2000) { out.partial = true; break; }
        const up = await d.get(key, { type: "json" }).catch(() => null);
        if (up && now - up.createdAt > 72 * 3600 * 1000) { await deleteUpload(up); await d.delete(key); out.uploads++; out.freed += up.size || 0; }
      }
      if (out.partial) break;
    }
  }
  if (out.freed) await addUsed(-out.freed);
  return out;
}

/** Pastrimi orar: videot e skaduara, kufizuesit e vjetër, dhe rillogaritja e saktë e ruajtjes së përdorur. */
export async function hourlyCleanup() {
  const d = adapter, now = Date.now(), t0 = now;
  const res = await purgeExpired(25000);
  let rates = 0;
  for (const { key } of (await d.list({ prefix: "meta/rate/" })).blobs) {
    const r = await d.get(key, { type: "json" }).catch(() => null);
    if (!r || now - (r.at ?? 0) > 3 * 3600 * 1000) { await d.delete(key); rates++; }
  }
  for (const { key } of (await d.list({ prefix: "meta/quota/" })).blobs) {
    const r = await d.get(key, { type: "json" }).catch(() => null);
    if (!r || now - (r.at ?? 0) > 48 * 3600 * 1000) await d.delete(key);
  }
  if (Date.now() - t0 < 20000) {
    let sum = 0, ok = true;
    for (const prefix of ["meta/videos/", "meta/uploads/"]) {
      for await (const page of d.list({ prefix, paginate: true })) {
        for (const { key } of page.blobs) {
          if (Date.now() - t0 > 28000) { ok = false; break; }
          const r = await d.get(key, { type: "json" }).catch(() => null);
          if (r?.size) sum += r.size;
        }
        if (!ok) break;
      }
    }
    if (ok) await d.setJSON("meta/stats", { bytes: sum, at: Date.now() });
  }
  console.log("[cleanup]", { ...res, rates });
}
