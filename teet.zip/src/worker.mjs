import api from "./api.mjs";
import { hourlyCleanup } from "./store.mjs";

const PAGES = { "/": "/index.html", "/dashboard": "/dashboard.html", "/admin": "/admin.html", "/kushtet": "/kushtet.html", "/privatesia": "/privatesia.html", "/kontakt": "/kontakt.html" };

function withHeaders(res, extra) {
  const r = new Response(res.body, res);
  for (const [k, v] of Object.entries(extra)) r.headers.set(k, v);
  return r;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const p = url.pathname.replace(/\/+$/, "") || "/";

    if (p.startsWith("/api/")) {
      const cc = req.headers.get("cf-ipcountry") || "";
      return api(req, { ip: req.headers.get("cf-connecting-ip") || "unknown", geo: { country: { code: /^[A-Z]{2}$/.test(cc) ? cc : "" } } });
    }

    let target = PAGES[p];
    let extra = {};
    if (/^\/v\/[^/]+\/manage$/.test(p)) { target = "/manage.html"; extra = { "x-robots-tag": "noindex, nofollow", "referrer-policy": "no-referrer" }; }
    else if (/^\/v\/[^/]+$/.test(p)) { target = "/v.html"; extra = { "x-robots-tag": "noindex, nofollow", "referrer-policy": "no-referrer" }; }
    else if (p === "/admin" || p === "/dashboard") extra = { "x-robots-tag": "noindex, nofollow", "cache-control": "no-store" };

    if (target) return withHeaders(await env.ASSETS.fetch(new Request(new URL(target, url), { method: "GET", headers: req.headers })), extra);
    return env.ASSETS.fetch(req);
  },

  async scheduled(_event, _env, ctx) {
    ctx.waitUntil(hourlyCleanup());
  },
};
